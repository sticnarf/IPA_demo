(function() {
  this.sessions_load = function() {
    return $('#members').addClass("active-menu").removeAttr("href");
  };

}).call(this);
